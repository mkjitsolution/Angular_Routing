import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WrongEndpointComponent } from './wrong-endpoint.component';

describe('WrongEndpointComponent', () => {
  let component: WrongEndpointComponent;
  let fixture: ComponentFixture<WrongEndpointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WrongEndpointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WrongEndpointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
