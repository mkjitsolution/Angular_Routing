import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrong-endpoint',
  templateUrl: './wrong-endpoint.component.html',
  styleUrls: ['./wrong-endpoint.component.css']
})
export class WrongEndpointComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
