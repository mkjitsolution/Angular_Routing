import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StockComponent } from './stock/stock.component';
import { PolicyComponent } from './policy/policy.component';
import { HomeComponent } from './home/home.component';
import { WrongEndpointComponent } from './wrong-endpoint/wrong-endpoint.component';
import { StockService } from './stock/shared/stock.service';
import { HttpClientModule} from '@angular/common/http';
import { StockDetailsComponent } from './stock/stock-details/stock-details.component';

@NgModule({
  declarations: [
    AppComponent,
    StockComponent,
    PolicyComponent,
    HomeComponent,
    WrongEndpointComponent,
    StockDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [StockService],
  bootstrap: [AppComponent]
})
export class AppModule { }