import { Stock.Model } from './stock.model';

describe('Stock.Model', () => {
  it('should create an instance', () => {
    expect(new Stock.Model()).toBeTruthy();
  });
});
