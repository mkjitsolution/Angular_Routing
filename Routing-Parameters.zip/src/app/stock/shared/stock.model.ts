export class Stock {
    private _companyName: string;
    public get companyName(): string {
        return this._companyName;
    }
    public set companyName(value: string) {
        this._companyName = value;
    }
    private _stockName: string;
    public get stockName(): string {
        return this._stockName;
    }
    public set stockName(value: string) {
        this._stockName = value;
    }
    private _cost: number;
    public get cost(): number {
        return this._cost;
    }
    public set cost(value: number) {
        this._cost = value;
    }
    private _MktCap: string;
    public get MktCap(): string {
        return this._MktCap;
    }
    public set MktCap(value: string) {
        this._MktCap = value;
    }
    private _PERatio: number;
    public get PERatio(): number {
        return this._PERatio;
    }
    public set PERatio(value: number) {
        this._PERatio = value;
    }
    private _prevClose: number;
    public get prevClose(): number {
        return this._prevClose;
    }
    public set prevClose(value: number) {
        this._prevClose = value;
    }
    private _wkHigh52: number;
    public get wkHigh52(): number {
        return this._wkHigh52;
    }
    public set wkHigh52(value: number) {
        this._wkHigh52 = value;
    }
    private _wkLow52: number;
    public get wkLow52(): number {
        return this._wkLow52;
    }
    public set wkLow52(value: number) {
        this._wkLow52 = value;
    }

    constructor(
        companyName: string,
        stockName:string,
        cost:number,
        MktCap:string,
        PERatio:number,
        prevClose:number,
        wkHigh52:number,
        wkLow52:number,
    )
    {
        this.companyName = companyName;
        this.stockName=stockName;
        this.cost = cost;
        this.MktCap = MktCap;
        this.PERatio = PERatio;
        this.prevClose = prevClose;
        this.wkHigh52 = wkHigh52;
        this.wkLow52 = wkLow52;
    }

    

}//end class
