import { Injectable } from '@angular/core';
import { Stock } from './stock.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StockService {

  stock = [];
  private endpoint = "assets/data/stockInfo.json";

  constructor(private http:HttpClient) { }

  getStocksFromServer():Observable<StockService[]>
   {
    return this.http.get<StockService[]>(this.endpoint);
   }



}
