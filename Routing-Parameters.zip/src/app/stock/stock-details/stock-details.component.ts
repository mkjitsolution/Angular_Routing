import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { StockService } from '../shared/stock.service';
@Component({
  selector: 'app-stock-details',
  templateUrl: './stock-details.component.html',
  styleUrls: ['./stock-details.component.css']
})
export class StockDetailsComponent implements OnInit {

  currentroute:ActivatedRoute;
  stockName:string;
  __stockService : StockService;

  constructor(route:ActivatedRoute,__stockService:StockService) {
    this.currentroute = route;
    this.__stockService = __stockService;
   }

  ngOnInit() {
    this.stockName = this.currentroute.snapshot.paramMap.get("stockName");
    console.log("--->> Stock details "+this.stockName);
    
  }

}
