import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StockComponent } from './stock/stock.component';
import { PolicyComponent } from './policy/policy.component';
import { WrongEndpointComponent } from './wrong-endpoint/wrong-endpoint.component';
import { HomeComponent } from './home/home.component';
import { StockDetailsComponent } from './stock/stock-details/stock-details.component';


const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"stocks",component:StockComponent},
  {path:"stocks/:stockName",component:StockDetailsComponent},
  {path:"policy",component:PolicyComponent},
  {path:"**",component:WrongEndpointComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
