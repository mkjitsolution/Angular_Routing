import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StockComponent } from './stock/stock.component';
import { PolicyComponent } from './policy/policy.component';


const routes: Routes = [
  {path:"stocks",component:StockComponent},
  {path:"policy",component:PolicyComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
